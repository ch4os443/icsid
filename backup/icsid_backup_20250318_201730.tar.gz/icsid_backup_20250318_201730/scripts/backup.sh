#!/bin/bash

# Configuração
BACKUP_DIR="backup"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_NAME="icsid_backup_${TIMESTAMP}"
BACKUP_PATH="${BACKUP_DIR}/${BACKUP_NAME}"

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${YELLOW}Iniciando backup do ICSID...${NC}"

# Cria diretório de backup se não existir
mkdir -p "${BACKUP_DIR}"

# Cria diretório do backup atual
mkdir -p "${BACKUP_PATH}"

# Backup do código fonte
echo -e "${YELLOW}Backup do código fonte...${NC}"
mkdir -p "${BACKUP_PATH}/src"
cp -r cmd internal pkg web "${BACKUP_PATH}/src/"
cp go.mod go.sum "${BACKUP_PATH}/src/"

# Backup de configurações
echo -e "${YELLOW}Backup de configurações...${NC}"
mkdir -p "${BACKUP_PATH}/config"
cp config.yaml "${BACKUP_PATH}/config/"

# Backup de certificados
echo -e "${YELLOW}Backup de certificados...${NC}"
mkdir -p "${BACKUP_PATH}/certs"
cp -r certs/* "${BACKUP_PATH}/certs/" 2>/dev/null || true

# Backup de scripts
echo -e "${YELLOW}Backup de scripts...${NC}"
mkdir -p "${BACKUP_PATH}/scripts"
cp -r scripts/* "${BACKUP_PATH}/scripts/"

# Backup de documentação
echo -e "${YELLOW}Backup de documentação...${NC}"
mkdir -p "${BACKUP_PATH}/docs"
cp -r docs/* "${BACKUP_PATH}/docs/"
cp README.md LICENSE "${BACKUP_PATH}/"

# Backup de binários compilados
echo -e "${YELLOW}Backup de binários...${NC}"
mkdir -p "${BACKUP_PATH}/bin"
cp icsid* "${BACKUP_PATH}/bin/" 2>/dev/null || true

# Cria arquivo de metadados
echo -e "${YELLOW}Gerando metadados...${NC}"
cat > "${BACKUP_PATH}/metadata.txt" << EOF
ICSID Backup
Data: $(date)
Versão: $(git describe --tags 2>/dev/null || echo "Não disponível")
Commit: $(git rev-parse HEAD)
Sistema: $(uname -a)
EOF

# Compacta o backup
echo -e "${YELLOW}Compactando backup...${NC}"
tar -czf "${BACKUP_PATH}.tar.gz" -C "${BACKUP_DIR}" "${BACKUP_NAME}"

# Remove diretório temporário
rm -rf "${BACKUP_PATH}"

# Verifica se o backup foi criado com sucesso
if [ -f "${BACKUP_PATH}.tar.gz" ]; then
    echo -e "${GREEN}Backup concluído com sucesso!${NC}"
    echo -e "${GREEN}Arquivo: ${BACKUP_PATH}.tar.gz${NC}"
else
    echo -e "${RED}Erro ao criar backup!${NC}"
    exit 1
fi

# Lista os últimos backups
echo -e "\n${YELLOW}Últimos backups:${NC}"
ls -lh "${BACKUP_DIR}"/*.tar.gz | tail -n 5 