#!/bin/bash

# Verifica se o Go está instalado
if ! command -v go &> /dev/null; then
    echo "Go não está instalado. Por favor, instale o Go 1.21 ou superior."
    exit 1
fi

# Verifica a versão do Go
go_version=$(go version | cut -d' ' -f3 | cut -d'.' -f2)
if [ "$go_version" -lt 21 ]; then
    echo "Versão do Go muito antiga. Por favor, instale o Go 1.21 ou superior."
    exit 1
fi

# Cria os diretórios necessários
echo "Criando diretórios..."
mkdir -p build dist certs tmp

# Instala as dependências
echo "Instalando dependências..."
go mod download

# Gera os certificados SSL
echo "Gerando certificados SSL..."
./scripts/generate_cert.sh

# Compila o projeto
echo "Compilando o projeto..."
./scripts/build.sh

echo "Instalação concluída!"